import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jkong',
    application_name='ginkgo-lambda-flask-api',
    app_uid='XrrfspS20rzFrcKX1K',
    org_uid='c566ecc3-426e-4826-9850-f0c342e81dc2',
    deployment_uid='40193fbb-80e4-479b-b1ed-5a1bb40ce600',
    service_name='ginkgo-lambda-flask-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.1.5',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'ginkgo-lambda-flask-api-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
